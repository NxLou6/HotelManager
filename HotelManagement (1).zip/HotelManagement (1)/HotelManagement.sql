-- Tạo cơ sở dữ liệu (nếu chưa tồn tại)
CREATE DATABASE HotelManagement;
GO

-- Sử dụng cơ sở dữ liệu
USE HotelManagement;
GO

-- Bảng Users (gộp admin và khách hàng)
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,          -- ID duy nhất
    FullName NVARCHAR(255) NOT NULL,              -- Họ và tên
    Email NVARCHAR(255) UNIQUE NOT NULL,          -- Email (duy nhất)
    PhoneNumber NVARCHAR(20) NULL,                -- Số điện thoại
    PasswordHash NVARCHAR(255) NOT NULL,          -- Mật khẩu (mã hóa)
    Role NVARCHAR(20) CHECK (Role IN ('admin', 'customer')) DEFAULT 'customer', -- Vai trò
    CreatedAt DATETIME DEFAULT GETDATE()          -- Ngày tạo tài khoản
);
GO

-- Bảng Rooms (Quản lý thông tin phòng)
CREATE TABLE Rooms (
    RoomID INT IDENTITY(1,1) PRIMARY KEY,         -- ID duy nhất của phòng
    RoomNumber NVARCHAR(50) NOT NULL,             -- Số phòng
    RoomType NVARCHAR(100) NOT NULL,              -- Loại phòng (ví dụ: đơn, đôi, suite)
    PricePerNight DECIMAL(10, 2) NOT NULL,        -- Giá mỗi đêm
    Status NVARCHAR(20) CHECK (Status IN ('Available', 'Booked')) DEFAULT 'Available', -- Trạng thái phòng
    Description NVARCHAR(MAX) NULL                -- Mô tả thêm
);
GO

-- Bảng Bookings (Quản lý đặt phòng)
CREATE TABLE Bookings (
    BookingID INT IDENTITY(1,1) PRIMARY KEY,      -- ID duy nhất của đặt phòng
    UserID INT NOT NULL,                          -- ID khách hàng
    RoomID INT NOT NULL,                          -- ID phòng
    CheckInDate DATE NOT NULL,                    -- Ngày nhận phòng
    CheckOutDate DATE NOT NULL,                   -- Ngày trả phòng
    TotalPrice DECIMAL(10, 2) NOT NULL,           -- Tổng tiền
    BookingStatus NVARCHAR(20) CHECK (BookingStatus IN ('Confirmed', 'Canceled')) DEFAULT 'confirmed', -- Trạng thái
    CreatedAt DATETIME DEFAULT GETDATE(),         -- Ngày tạo đặt phòng
    FOREIGN KEY (UserID) REFERENCES Users(UserID), -- Khóa ngoại liên kết tới bảng Users
    FOREIGN KEY (RoomID) REFERENCES Rooms(RoomID)  -- Khóa ngoại liên kết tới bảng Rooms
);
GO
