package controller.admin;

import dal.BookingDAO;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class TotalBookingsServlet extends HttpServlet {   
   
    // Process the request for both GET and POST methods
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        BookingDAO bookingDAO = new BookingDAO();
        List<Object[]> revenueData = bookingDAO.getTotalRevenueByRoom();

        // Đưa dữ liệu vào request attribute
        request.setAttribute("re", revenueData);

        // Chuyển tiếp đến trang JSP
        request.getRequestDispatcher("/admin/revenue.jsp").forward(request, response);
    }

    // Handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response); // Process the request for GET
    }

    // Handle POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response); // Process the request for POST
    }

    @Override
    public String getServletInfo() {
        return "Servlet for calculating total bookings and revenue statistics";
    }
}