package controller.customer;

import dal.RoomDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import model.Rooms;

public class SearchRoomServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Lấy các tham số từ request
        String roomType = request.getParameter("roomType");
        String minPriceStr = request.getParameter("minPrice");
        String maxPriceStr = request.getParameter("maxPrice");
        String description = request.getParameter("description");

        // Xử lý giá trị minPrice và maxPrice
        Double minPrice = null;
        Double maxPrice = null;

        try {
            if (minPriceStr != null && !minPriceStr.trim().isEmpty()) {
                minPrice = Double.parseDouble(minPriceStr);
            }
        } catch (NumberFormatException e) {
            minPrice = null; // Giá trị mặc định nếu người dùng nhập sai định dạng
        }

        try {
            if (maxPriceStr != null && !maxPriceStr.trim().isEmpty()) {
                maxPrice = Double.parseDouble(maxPriceStr);
            }
        } catch (NumberFormatException e) {
            maxPrice = null; // Giá trị mặc định nếu người dùng nhập sai định dạng
        }

        // Tạo DAO để tìm kiếm phòng
        RoomDAO roomDAO = new RoomDAO();
        List<Rooms> rooms = roomDAO.searchRooms(roomType, minPrice, maxPrice, description);

        // Đặt danh sách phòng vào attribute để hiển thị trong JSP
        request.setAttribute("rooms", rooms);

        // Chuyển tiếp tới trang kết quả (rooms.jsp hoặc trang hiển thị danh sách phòng)
        request.getRequestDispatcher("/customer/allRoom.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Có thể gọi doGet để xử lý POST nếu không có xử lý riêng
        doGet(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Search Room Servlet handles search queries based on type, price, and description.";
    }
}
