/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller.customer;

import dal.BookingDAO;
import dal.RoomDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.Date;
import model.Bookings;
import model.Rooms;
import model.Users;

/**
 *
 * @author Administrator
 */
public class BookRoomServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet BookRoomServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet BookRoomServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        int roomId = Integer.parseInt(request.getParameter("roomId"));

        RoomDAO rdao = new RoomDAO();
        Rooms r = rdao.getRoomById(roomId);
        request.setAttribute("room", r);

        request.getRequestDispatcher("/customer/bookRoom.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        // Lấy thông tin từ form
        int roomId = Integer.parseInt(request.getParameter("roomID"));
        String userName = request.getParameter("userName");
        Date checkInDate = Date.valueOf(request.getParameter("checkInDate"));
        Date checkOutDate = Date.valueOf(request.getParameter("checkOutDate"));
        double pricePerNight = Double.parseDouble(request.getParameter("pricePerNight"));
        // Lấy ngày hiện tại
        Date today = new Date(System.currentTimeMillis());

        // Kiểm tra ngày Check-in phải từ hôm nay trở đi
        if (checkInDate.before(today)) {
            // Gửi thông báo lỗi về trang đặt phòng
            request.setAttribute("error", "Check-in date must not be before today.");
            RoomDAO rdao = new RoomDAO();
            Rooms r = rdao.getRoomById(roomId);
            request.setAttribute("room", r);
            request.getRequestDispatcher("/customer/bookRoom.jsp").forward(request, response);
            return;
        }
// Kiểm tra ngày checkout phải lớn hơn ngày checkin
        if (!checkOutDate.after(checkInDate)) {
            // Gửi thông báo lỗi về trang đặt phòng
            
            request.setAttribute("error", "Checkout date must be later than check-in date.");
            RoomDAO rdao = new RoomDAO();
            Rooms r = rdao.getRoomById(roomId);
            request.setAttribute("room", r);
            request.getRequestDispatcher("/customer/bookRoom.jsp").forward(request, response);
            return;
        }
        // Tính toán tổng tiền
        long diffInMillies = checkOutDate.getTime() - checkInDate.getTime();
        long daysStayed = diffInMillies / (1000 * 60 * 60 * 24);
        double totalPrice = daysStayed * pricePerNight;
        HttpSession session = request.getSession();
        Users u = (Users) session.getAttribute("account");

        // Lưu thông tin booking vào cơ sở dữ liệu
        BookingDAO bookingDAO = new BookingDAO();
        Bookings booking = new Bookings();
        booking.setUserID(u.getUserID()); // Thay đổi giá trị này cho phù hợp với người dùng đăng nhập
        booking.setRoomID(roomId);
        booking.setCheckInDate(checkInDate);
        booking.setCheckOutDate(checkOutDate);
        booking.setTotalPrice(totalPrice);
        booking.setBookingStatus("confirmed"); // Trạng thái mặc định
        booking.setCreatedAt(new java.sql.Timestamp(System.currentTimeMillis()));

        boolean isSuccess = bookingDAO.addBooking(booking);

        RoomDAO rdao = new RoomDAO();
        rdao.updateRoomStatus(roomId, "Booked");
        // Chuyển hướng tới trang xác nhận sau khi đặt phòng thành công
        if (isSuccess) {

            response.sendRedirect("allRoom"); // Trang xác nhận
        } else {
            response.sendRedirect("error.jsp"); // Trang lỗi nếu đặt phòng thất bại
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
