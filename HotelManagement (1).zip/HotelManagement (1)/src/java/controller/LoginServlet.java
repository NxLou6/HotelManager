/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dal.UserDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Users;

/**
 *
 * @author Administrator
 */
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LoginServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = "";
        String password = "";

        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("email".equals(cookie.getName())) {
                    email = cookie.getValue();
                }
                if ("pass".equals(cookie.getName())) {
                    password = cookie.getValue();
                }
            }
        }

        request.setAttribute("email", email);
        request.setAttribute("password", password);

        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        //processRequest(request, response);
        String email = request.getParameter("email");
        String pass = request.getParameter("password");
        String rememberMe = request.getParameter("remember");

        HttpSession session = request.getSession();
        // Check if the account exists
        UserDAO udao = new UserDAO();

        if (!udao.checkEmailExists(email)) {
            request.setAttribute("err", "Account does not exist! Please sign up!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        } else {
            Users u = udao.checkCredentials(email, pass);
            if (u != null) {
                session.setAttribute("account", u);

                if (u.getRole().equals("admin")) {
                    // đi tới admin
                    response.sendRedirect(request.getContextPath() + "/showRoom");
                } else {
                    // đi tới khách hàng
                    response.sendRedirect(request.getContextPath() + "/allRoom");
                }
            } else {
                request.setAttribute("err", "Password is not correct! Please try again!");
                request.getRequestDispatcher("login.jsp").forward(request, response);
                return;
            }
        }

        // If "Remember Me" is checked, set cookies for email and password (or a token)
        if ("on".equals(rememberMe)) {
            Cookie emailCookie = new Cookie("email", email);
            Cookie passCookie = new Cookie("pass", pass); // Not recommended in real applications

            // Set cookies to last for 7 days
            emailCookie.setMaxAge(7 * 24 * 60 * 60); // 7 days
            passCookie.setMaxAge(7 * 24 * 60 * 60);

            response.addCookie(emailCookie);
            response.addCookie(passCookie);
        } else {
            // If "Remember Me" is not checked, clear any existing cookies
            Cookie emailCookie = new Cookie("email", "");
            Cookie passCookie = new Cookie("pass", "");
            emailCookie.setMaxAge(0);
            passCookie.setMaxAge(0);
            response.addCookie(emailCookie);
            response.addCookie(passCookie);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
