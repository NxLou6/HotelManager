/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Rooms;

/**
 *
 * @author Administrator
 */
public class RoomDAO extends DBContext {

    public List<Rooms> getAllRooms() {
        List<Rooms> rooms = new ArrayList<>();
        String query = "SELECT * FROM Rooms";

        try (PreparedStatement ps = connection.prepareStatement(query); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Rooms room = new Rooms();
                room.setRoomID(rs.getInt("RoomID"));
                room.setRoomNumber(rs.getString("RoomNumber"));
                room.setRoomType(rs.getString("RoomType"));
                room.setPricePerNight(rs.getDouble("PricePerNight"));
                room.setStatus(rs.getString("Status"));
                room.setDescription(rs.getString("Description"));
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }

    public boolean addRoom(String roomnumber, String roomType, double price, String des) {
        String query = "INSERT INTO Rooms (RoomNumber, RoomType, PricePerNight, Description) VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            // Set the parameters for the query
            ps.setString(1, roomnumber);
            ps.setString(2, roomType);
            ps.setDouble(3, price);
            ps.setString(4, des);

            // Execute the update
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Return true if the room was added successfully
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Return false if an exception occurred
    }

    public boolean deleteRoom(int roomId) {
        String checkBookingsQuery = "SELECT COUNT(*) FROM Bookings WHERE RoomID = ?";
        String deleteBookingsQuery = "DELETE FROM Bookings WHERE RoomID = ?";  // Câu lệnh xóa bản ghi trong Bookings
        String deleteRoomQuery = "DELETE FROM Rooms WHERE RoomID = ?";  // Câu lệnh xóa phòng trong Rooms

        try (PreparedStatement checkPs = connection.prepareStatement(checkBookingsQuery)) {
            // Kiểm tra xem phòng có liên kết với bản ghi nào trong Bookings không
            checkPs.setInt(1, roomId);
            ResultSet rs = checkPs.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                // Nếu có bản ghi liên quan, tiến hành xóa các bản ghi trong Bookings
                try (PreparedStatement deleteBookingsPs = connection.prepareStatement(deleteBookingsQuery)) {
                    deleteBookingsPs.setInt(1, roomId);
                    int bookingsDeleted = deleteBookingsPs.executeUpdate();  // Thực hiện xóa trong Bookings
                    System.out.println(bookingsDeleted + " bookings deleted for RoomID: " + roomId);
                } catch (SQLException e) {
                    e.printStackTrace();
                    return false;  // Nếu có lỗi khi xóa bookings, trả về false
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;  // Nếu có lỗi khi kiểm tra bookings, trả về false
        }

        // Thực hiện xóa phòng sau khi đã xóa bookings liên quan
        try (PreparedStatement deletePs = connection.prepareStatement(deleteRoomQuery)) {
            deletePs.setInt(1, roomId);
            int rowsAffected = deletePs.executeUpdate();  // Thực hiện xóa trong Rooms
            return rowsAffected > 0;  // Trả về true nếu xóa thành công
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;  // Trả về false nếu có lỗi khi xóa phòng
    }

    public boolean updateRoom(int roomId, String roomNumber, String roomType, double price, String description) {
        String updateQuery = "UPDATE Rooms SET RoomNumber = ?, RoomType = ?, PricePerNight = ?, Description = ? WHERE RoomID = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateQuery)) {
            ps.setString(1, roomNumber);
            ps.setString(2, roomType);
            ps.setDouble(3, price);
            ps.setString(4, description);
            ps.setInt(5, roomId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Trả về true nếu cập nhật thành công
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Trả về false nếu có lỗi xảy ra
    }

    public Rooms getRoomById(int roomId) {
        String query = "SELECT * FROM Rooms WHERE RoomID = ?";
        Rooms room = null;

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, roomId); // Set RoomID vào câu lệnh truy vấn
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Khởi tạo đối tượng Rooms và gán giá trị từ ResultSet
                room = new Rooms();
                room.setRoomID(rs.getInt("RoomID"));
                room.setRoomNumber(rs.getString("RoomNumber"));
                room.setRoomType(rs.getString("RoomType"));
                room.setPricePerNight(rs.getDouble("PricePerNight"));
                room.setStatus(rs.getString("Status"));
                room.setDescription(rs.getString("Description"));
            }
        } catch (SQLException e) {
            e.printStackTrace(); // In lỗi ra console để debug
        }
        return room; // Trả về đối tượng Rooms (hoặc null nếu không tìm thấy)
    }

    public boolean checkRoomName(String roomNumber) {
        String query = "SELECT COUNT(*) FROM Rooms WHERE RoomNumber = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, roomNumber); // Set giá trị roomNumber vào câu lệnh truy vấn
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1); // Đếm số lượng phòng có RoomNumber tương ứng
                return count > 0; // Nếu count > 0, tức là phòng đã tồn tại
            }
        } catch (SQLException e) {
            e.printStackTrace(); // In lỗi nếu có
        }
        return false; // Trả về false nếu không tìm thấy phòng
    }

    public boolean updateRoomStatus(int roomId, String status) {
        String query = "UPDATE Rooms SET Status = ? WHERE RoomID = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, status); // Gán giá trị trạng thái mới
            ps.setInt(2, roomId);    // Gán giá trị RoomID
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Trả về true nếu cập nhật thành công
        } catch (SQLException e) {
            e.printStackTrace(); // In lỗi ra console để debug
        }
        return false; // Trả về false nếu có lỗi xảy ra
    }

    public List<Rooms> searchRooms(String roomType, Double minPrice, Double maxPrice, String description) {
        List<Rooms> rooms = new ArrayList<>();
        StringBuilder query = new StringBuilder("SELECT * FROM Rooms WHERE 1=1");

        // Thêm điều kiện cho từng tiêu chí nếu có
        if (roomType != null && !roomType.isEmpty()) {
            query.append(" AND RoomType LIKE ?");
        }
        if (minPrice != null) {
            query.append(" AND PricePerNight >= ?");
        }
        if (maxPrice != null) {
            query.append(" AND PricePerNight <= ?");
        }
        if (description != null && !description.isEmpty()) {
            query.append(" AND Description LIKE ?");
        }

        try (PreparedStatement ps = connection.prepareStatement(query.toString())) {
            int paramIndex = 1;

            // Gán giá trị tham số cho câu truy vấn
            if (roomType != null && !roomType.isEmpty()) {
                ps.setString(paramIndex++, "%" + roomType + "%");
            }
            if (minPrice != null) {
                ps.setDouble(paramIndex++, minPrice);
            }
            if (maxPrice != null) {
                ps.setDouble(paramIndex++, maxPrice);
            }
            if (description != null && !description.isEmpty()) {
                ps.setString(paramIndex++, "%" + description + "%");
            }

            // Thực thi câu truy vấn và xử lý kết quả
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Rooms room = new Rooms();
                room.setRoomID(rs.getInt("RoomID"));
                room.setRoomNumber(rs.getString("RoomNumber"));
                room.setRoomType(rs.getString("RoomType"));
                room.setPricePerNight(rs.getDouble("PricePerNight"));
                room.setStatus(rs.getString("Status"));
                room.setDescription(rs.getString("Description"));
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // In lỗi để kiểm tra
        }
        return rooms; // Trả về danh sách phòng
    }

}
