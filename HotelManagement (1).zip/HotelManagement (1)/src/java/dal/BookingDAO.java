/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Bookings;

/**
 *
 * @author Administrator
 */
public class BookingDAO extends DBContext {

    public List<Bookings> getAllBookings() {
        List<Bookings> bookings = new ArrayList<>();
        String query = "SELECT * FROM Bookings order by bookingID DESC";

        try (PreparedStatement ps = connection.prepareStatement(query); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Bookings booking = new Bookings();
                booking.setBookingID(rs.getInt("BookingID"));
                booking.setUserID(rs.getInt("UserID"));
                booking.setRoomID(rs.getInt("RoomID"));
                booking.setCheckInDate(rs.getDate("CheckInDate"));
                booking.setCheckOutDate(rs.getDate("CheckOutDate"));
                booking.setTotalPrice(rs.getDouble("TotalPrice"));
                booking.setBookingStatus(rs.getString("BookingStatus"));
                booking.setCreatedAt(rs.getTimestamp("CreatedAt"));
                bookings.add(booking);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookings;
    }

    public boolean addBooking(Bookings booking) {
        String query = "INSERT INTO Bookings (UserID, RoomID, CheckInDate, CheckOutDate, TotalPrice, BookingStatus, CreatedAt) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, booking.getUserID());
            ps.setInt(2, booking.getRoomID());
            ps.setDate(3, booking.getCheckInDate());
            ps.setDate(4, booking.getCheckOutDate());
            ps.setDouble(5, booking.getTotalPrice());
            ps.setString(6, booking.getBookingStatus());
            ps.setTimestamp(7, booking.getCreatedAt());
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Nếu số dòng bị ảnh hưởng > 0, trả về true
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Trả về false nếu có lỗi xảy ra
    }

    public List<Bookings> getBookingByUserId(int userId) {
        List<Bookings> bookings = new ArrayList<>();
        String query = "SELECT * FROM Bookings WHERE UserID = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            // Set parameter for UserID
            ps.setInt(1, userId);

            // Execute the query and get results
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    // Create and populate the Booking object
                    Bookings booking = new Bookings();
                    booking.setBookingID(rs.getInt("bookingID"));
                    booking.setUserID(rs.getInt("UserID"));
                    booking.setRoomID(rs.getInt("RoomID"));
                    booking.setCheckInDate(rs.getDate("CheckInDate"));
                    booking.setCheckOutDate(rs.getDate("CheckOutDate"));
                    booking.setTotalPrice(rs.getDouble("TotalPrice"));
                    booking.setBookingStatus(rs.getString("BookingStatus"));
                    booking.setCreatedAt(rs.getTimestamp("CreatedAt"));

                    // Add the booking to the list
                    bookings.add(booking);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bookings; // Return the list of bookings
    }

    public boolean updateBookingStatus(int bookingID, String newStatus) {
        String query = "UPDATE Bookings SET BookingStatus = ? WHERE BookingID = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, newStatus); // Trạng thái mới (e.g., "Canceled")
            ps.setInt(2, bookingID); // ID của booking cần cập nhật

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Trả về true nếu có ít nhất một hàng được cập nhật
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Trả về false nếu có lỗi xảy ra
    }

    public Bookings getBookingByBookingID(int bookingID) {
        Bookings booking = null;
        String query = "SELECT * FROM Bookings WHERE BookingID = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            // Set parameter for BookingID
            ps.setInt(1, bookingID);

            // Execute the query and get results
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Create and populate the Booking object
                    booking = new Bookings();
                    booking.setBookingID(rs.getInt("BookingID"));
                    booking.setUserID(rs.getInt("UserID"));
                    booking.setRoomID(rs.getInt("RoomID"));
                    booking.setCheckInDate(rs.getDate("CheckInDate"));
                    booking.setCheckOutDate(rs.getDate("CheckOutDate"));
                    booking.setTotalPrice(rs.getDouble("TotalPrice"));
                    booking.setBookingStatus(rs.getString("BookingStatus"));
                    booking.setCreatedAt(rs.getTimestamp("CreatedAt"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return booking; // Return the booking object, or null if no booking was found
    }

    public double getTotalBookingsByMonth(int month, int year) {
        double total = 0.0;
        String query = "SELECT SUM(TotalPrice) AS TotalAmount "
                + "FROM Bookings "
                + "WHERE BookingStatus = 'Confirmed' AND ("
                + "(MONTH(CheckInDate) = ? AND YEAR(CheckInDate) = ?) OR "
                + "(MONTH(CheckOutDate) = ? AND YEAR(CheckOutDate) = ?))";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            // Set the month and year parameters
            ps.setInt(1, month);
            ps.setInt(2, year);
            ps.setInt(3, month);
            ps.setInt(4, year);

            // Execute the query and get the result
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    total = rs.getDouble("TotalAmount"); // Retrieve the sum of the total price
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return total; // Return the total amount for the given month and year with "Confirmed" status
    }

    public double getTotalRevenueByMonth(int month, int year) {
        return getTotalBookingsByMonth(month, year); // You can modify this logic to fetch specific monthly revenue if needed
    }
    public List<Object[]> getTotalRevenueByRoom() {
        List<Object[]> revenueList = new ArrayList<>();
        String query = "SELECT RoomID, SUM(TotalPrice) AS TotalRevenue "
                + "FROM Bookings "
                + "WHERE BookingStatus = 'confirmed' "
                + "GROUP BY RoomID";

        try (PreparedStatement ps = connection.prepareStatement(query); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Object[] row = new Object[2];
                row[0] = rs.getInt("RoomID"); // Room ID
                row[1] = rs.getDouble("TotalRevenue"); // Total revenue
                revenueList.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return revenueList;
    }
}

